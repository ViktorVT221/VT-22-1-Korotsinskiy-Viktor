const Product = require('../models/Product');
const Category = require('../models/Category');
const path = require('path');
const fs = require('fs');

// Helper function to upload images
const uploadImage = (file) => {
    try {
        const uploadDir = path.join(__dirname, '../public/uploads');
        const uploadPath = path.join(uploadDir, file.name);

        // Ensure directory exists
        if (!fs.existsSync(uploadDir)){
            fs.mkdirSync(uploadDir, { recursive: true });
        }

        console.log(`Uploading image to: ${uploadPath}`);
        file.mv(uploadPath, (err) => {
            if (err) {
                console.error('Error during file upload:', err);
                throw new Error('Image upload failed');
            }
        });
        return `/uploads/${file.name}`;
    } catch (err) {
        console.error('Error in uploadImage function:', err);
        throw err;
    }
};

// Product CRUD operations
exports.getAllProducts = async (req, res) => {
    try {
        const products = await Product.findAll({ include: Category });
        res.render('admin/products', { title: 'Manage Products', products });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.createProduct = async (req, res) => {
    const { name, description, price, categoryId } = req.body;
    try {
        const imageUrl = uploadImage(req.files.image);
        const product = await Product.create({ name, description, imageUrl, price, categoryId });
        res.redirect('/admin/products');
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.renderNewProductPage = async (req, res) => {
    console.log('Trying to Rendering new product page');
    try {
        const categories = await Category.findAll();
        console.log('Rendering new product page, categories:', categories);
        res.render('admin/newProduct', { categories });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.render('error', { title: 'Error', error: error.message });
    }
};


exports.updateProduct = async (req, res) => {
    const { id } = req.params;
    const { name, description, price, categoryId } = req.body;
    try {
        const product = await Product.findByPk(id);
        if (product) {
            product.name = name;
            product.description = description;
            product.price = price;
            product.categoryId = categoryId;
            if (req.files && req.files.image) {
                const imageUrl = uploadImage(req.files.image);
                product.imageUrl = imageUrl;
            }
            await product.save();
            res.redirect('/admin/products');
        } else {
            res.render('error', { title: 'Error', error: 'Product not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.deleteProduct = async (req, res) => {
    const { id } = req.params;
    try {
        const product = await Product.findByPk(id);
        if (product) {
            await product.destroy();
            res.redirect('/admin/products');
        } else {
            res.render('error', { title: 'Error', error: 'Product not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id);
        if (!product) {
            res.status(404).send('Product not found');
            return null;
        }
        return product;
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).send('Server error');
        return null;
    }
};


// Category CRUD operations
exports.getAllCategories = async (req, res) => {
    try {
        const categories = await Category.findAll();
        res.render('admin/categories', { title: 'Manage Categories', categories });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.createCategory = async (req, res) => {
    const { name } = req.body;
    try {
        const category = await Category.create({ name });
        res.redirect('/admin/categories');
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.updateCategory = async (req, res) => {
    const { id } = req.params;
    const { name } = req.body;
    try {
        const category = await Category.findByPk(id);
        if (category) {
            category.name = name;
            await category.save();
            res.redirect('/admin/categories');
        } else {
            res.render('error', { title: 'Error', error: 'Category not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.deleteCategory = async (req, res) => {
    const { id } = req.params;
    try {
        const category = await Category.findByPk(id);
        if (category) {
            await category.destroy();
            res.redirect('/admin/categories');
        } else {
            res.render('error', { title: 'Error', error: 'Category not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};
