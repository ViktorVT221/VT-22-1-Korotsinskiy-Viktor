const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Login
exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ where: { username } });
        if (user && bcrypt.compareSync(password, user.password)) {
            const token = jwt.sign({ userId: user.id, isAdmin: user.isAdmin }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.cookie('token', token, { httpOnly: true });
            console.log(`User logged in: ${username}, isAdmin: ${user.isAdmin}`);
            res.redirect('/');
        } else {
            console.log(`Failed login attempt: ${username}`);
            res.render('auth/login', { title: 'Login', error: 'Invalid credentials' });
        }
    } catch (error) {
        console.error(`Login error for user: ${username}`, error);
        res.render('auth/login', { title: 'Login', error: error.message });
    }
};

// Register
exports.register = async (req, res) => {
    const { username, password, isAdmin } = req.body;
    try {
        console.log("Registering user:", { username, isAdmin }); // Додавання журналу
        const hashedPassword = bcrypt.hashSync(password, 8);
        const user = await User.create({ 
            username, 
            password: hashedPassword, 
            isAdmin: isAdmin === 'on' // Перевірка значення checkbox
        });
        console.log(`User registered: ${username}, isAdmin: ${user.isAdmin}`);
        res.redirect('/auth/login');
    } catch (error) {
        console.error(`Registration error for user: ${username}`, error);
        res.render('auth/register', { title: 'Register', error: error.message });
    }
};


exports.getRegisterPage = (req, res) => {
    res.render('auth/register', { title: 'Register' });
};

exports.getLoginPage = (req, res) => {
    res.render('auth/login', { title: 'Login' });
};
