const Product = require('../models/Product');
const Category = require('../models/Category');

exports.getAllProducts = async (req, res) => {
    try {
        const categoryId = req.query.categoryId;
        const categories = await Category.findAll();
        const query = categoryId ? { where: { categoryId }, include: Category } : { include: Category };
        const products = await Product.findAll(query);
        res.render('products', { title: 'Products', products, categories, selectedCategoryId: categoryId });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.createProduct = async (req, res) => {
    const { name, description, price, stock } = req.body;
    try {
        const product = await Product.create({ name, description, price, stock });
        res.redirect('/admin/products');
    } catch (error) {
        res.render('admin/newProduct', { title: 'Add Product', error: error.message });
    }
};

exports.updateProduct = async (req, res) => {
    const { id } = req.params;
    const { name, description, price, stock } = req.body;
    try {
        const product = await Product.findByPk(id);
        if (product) {
            product.name = name;
            product.description = description;
            product.price = price;
            product.stock = stock;
            await product.save();
            res.redirect('/admin/products');
        } else {
            res.render('error', { title: 'Error', error: 'Product not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

exports.deleteProduct = async (req, res) => {
    const { id } = req.params;
    try {
        const product = await Product.findByPk(id);
        if (product) {
            await product.destroy();
            res.redirect('/admin/products');
        } else {
            res.render('error', { title: 'Error', error: 'Product not found' });
        }
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

// Method for fetching product details
exports.getProductDetails = async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id, { include: Category });
        if (!product) {
            res.status(404).send('Product not found');
            return;
        }
        res.render('productDetails', { title: product.name, product });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
};

