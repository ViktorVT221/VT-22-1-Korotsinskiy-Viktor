const jwt = require('jsonwebtoken');
const User = require('../models/User');

const isAuthenticated = (req, res, next) => {
    const token = req.cookies.token;
    if (token) {
        jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
            if (err) {
                return res.status(401).json({ message: 'Unauthorized' });
            }
            req.user = await User.findByPk(decoded.userId);
            console.log(`Middleware isAuthenticated: userId=${req.user.id}, isAdmin=${req.user.isAdmin}`);
            res.locals.user = req.user;
            next();
        });
    } else {
        res.locals.user = null;
        next();
    }
};

const isAdmin = (req, res, next) => {
    isAuthenticated(req, res, () => {
        if (req.user && req.user.isAdmin) {
            console.log(`Middleware isAdmin: userId=${req.user.id}, isAdmin=${req.user.isAdmin}`);
            next();
        } else {
            res.status(403).json({ message: 'Forbidden' });
        }
    });
};

module.exports = { isAuthenticated, isAdmin };
