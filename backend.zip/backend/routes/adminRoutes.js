const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { isAdmin } = require('../middleware/authMiddleware');

// Admin Dashboard
router.get('/dashboard', isAdmin, (req, res) => {
    res.render('admin/dashboard', { username: req.user.username });
});

// Manage Products
router.get('/products', isAdmin, adminController.getAllProducts);
router.get('/products/new', isAdmin, adminController.renderNewProductPage);
router.post('/products', isAdmin, adminController.createProduct);
router.get('/products/:id/edit', isAdmin, async (req, res) => {
    const product = await adminController.getProductById(req, res);
    if (!product) {
        return; // Припиняємо виконання, якщо продукт не знайдено або сталася помилка
    }
    const categories = await adminController.getAllCategories(req, res);
    res.render('admin/editProduct', { product, categories });
});

router.post('/products/:id', isAdmin, adminController.updateProduct);
router.post('/products/:id/delete', isAdmin, adminController.deleteProduct);

// Manage Categories
router.get('/categories', isAdmin, adminController.getAllCategories);
router.get('/categories/new', isAdmin, (req, res) => {
    res.render('admin/newCategory');
});
router.post('/categories', isAdmin, adminController.createCategory);
router.get('/categories/:id/edit', isAdmin, async (req, res) => {
    const category = await adminController.getCategoryById(req, res);
    res.render('admin/editCategory', { category });
});
router.post('/categories/:id', isAdmin, adminController.updateCategory);
router.post('/categories/:id/delete', isAdmin, adminController.deleteCategory);

module.exports = router;
