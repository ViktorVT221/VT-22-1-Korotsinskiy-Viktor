const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const Product = require('../models/Product');
const Category = require('../models/Category');

// Existing routes for product CRUD operations
router.get('/', productController.getAllProducts);
router.post('/', productController.createProduct);
router.put('/:id', productController.updateProduct);
router.delete('/:id', productController.deleteProduct);

// New routes for displaying products to users
router.get('/list', async (req, res) => {
    try {
        const categoryId = req.query.categoryId;
        const categories = await Category.findAll();
        const query = categoryId ? { where: { categoryId }, include: Category } : { include: Category };
        const products = await Product.findAll(query);
        res.render('products', { title: 'Products', products, categories, selectedCategoryId: categoryId });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
});

router.get('/list/:id', async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id, { include: Category });
        if (!product) {
            res.status(404).send('Product not found');
            return;
        }
        res.render('productDetails', { title: product.name, product });
    } catch (error) {
        res.render('error', { title: 'Error', error: error.message });
    }
});

module.exports = router;
