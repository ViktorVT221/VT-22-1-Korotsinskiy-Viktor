const { Category } = require('../models/category');
const sequelize = require('../config/database');

const categories = [
    { name: 'Футбол' },
    { name: 'Баскетбол' },
    { name: 'Теніс' },
    { name: 'Фітнес' }
];

sequelize.sync({ force: false }).then(async () => {
    try {
        await Category.bulkCreate(categories);
        console.log('Категорії успішно створені.');
        process.exit();
    } catch (error) {
        console.error('Помилка при створенні категорій:', error);
        process.exit(1);
    }
});
